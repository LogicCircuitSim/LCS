--==============================================================[ imports ]===================================================================--

io.stdout:setvbuf("no")
local lume = require("lib.lume")
local inspect = require("lib.inspect")
local Class = require("lib.class")
local gui = require('gui'):new()

--=============================================================[ variables ]==================================================================--

lg = love.graphics
lm = love.mouse

printGui = false

local font = love.graphics.newFont("assets/univga16.ttf", 16, "none")
font:setFilter("nearest")
local fontHeight = font:getHeight()

local contextMenu = nil
local showContextMenu = false
local padding = 10

local gateSize = { width = 100, height = 50 }
local gates = {}

local isConnectingCable = false
local firstConnectionPinID = 0
local firstConnectionPinPos = { x = 0, y = 0}
local connections = {}

local menu = nil
local menuEnum = {
	menu = 1, board = 2, options = 3
}
local menuState = menuEnum.menu

--==========================================================[ custom functions ]==============================================================--

local function bounds(x, y, w, h)
    local b = {}
	b.x, b.y, b.w, b.h = x, y, w, h
	return b
end

local function posi(x, y)
    local p = {}
	p.x, p.y = x, y
	return p
end

function mandist(a, b)
    return math.abs(b.x - a.x) + math.abs(b.y - a.y)
end

function mouseInRange(pos, range)
	local x, y = lm.getPosition()
	return mandist(posi(x, y), pos) <= range
end

function mouseInBox(bounds)
	local x, y = lm.getPosition()
	return x >= bounds.x and x <= bounds.x+bounds.w and y >= bounds.y and y <= bounds.y+bounds.h
end

local currentID = 1
local function generateNewID()
	currentID = currentID+1
	return currentID
end

local function findPosByID(id)
	local pos = {}
	for _,gate in ipairs(gates) do
		if gate.firstInputpinID == id then
			pos = posi(gate.firstInputPinPos.x, gate.firstInputPinPos.y)
		end
	end
	return pos
end

local function connectPins(secondConnectionPinID)
	table.insert(connections, { first = firstConnectionPinID, second = secondConnectionPinID })
end

local function drawGateTwoPins(p)
	lg.setColor(0.2, 0.2, 0.2)
	lg.rectangle("fill", p.x, p.y, gateSize.width, gateSize.height)		
	love.graphics.setLineWidth(3)
	lg.line(p.x, p.y + (gateSize.height/4), p.x - (gateSize.width/5), p.y + (gateSize.height/4))
	lg.line(p.x, p.y + (gateSize.height/4*3), p.x - (gateSize.width/5), p.y + (gateSize.height/4*3))		
	lg.line(p.x + gateSize.width, p.y + (gateSize.height/2), p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2))

	lg.setColor(0, 0, 0)
	lg.circle("fill", p.x - (gateSize.width/5), p.y + (gateSize.height/4), 5)
	lg.circle("fill", p.x - (gateSize.width/5), p.y + (gateSize.height/4*3), 5)
	lg.circle("fill", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)

	lg.setColor(1, 1, 1)		
	love.graphics.setLineWidth(1)
	lg.rectangle("line", p.x, p.y, gateSize.width, gateSize.height)
	lg.circle("line", p.x - (gateSize.width/5), p.y + (gateSize.height/4), 5)
	lg.circle("line", p.x - (gateSize.width/5), p.y + (gateSize.height/4*3), 5)
	lg.circle("line", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)
end

local function drawGateOnePin(p)
	lg.setColor(0.2, 0.2, 0.2)
	lg.rectangle("fill", p.x, p.y, gateSize.width, gateSize.height)		
	love.graphics.setLineWidth(3)
	lg.line(p.x, p.y + (gateSize.height/2), p.x - (gateSize.width/5), p.y + (gateSize.height/2))
	lg.line(p.x + gateSize.width, p.y + (gateSize.height/2), p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2))

	lg.setColor(0, 0, 0)
	lg.circle("fill", p.x - (gateSize.width/5), p.y + (gateSize.height/2), 5)
	lg.circle("fill", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)

	lg.setColor(1, 1, 1)		
	love.graphics.setLineWidth(1)
	lg.rectangle("line", p.x, p.y, gateSize.width, gateSize.height)
	lg.circle("line", p.x - (gateSize.width/5), p.y + (gateSize.height/2), 5)
	lg.circle("line", p.x + gateSize.width + (gateSize.width/5), p.y + (gateSize.height/2), 5)
end

--==========================================================[ custom classes ]==============================================================--

AND = Class{
    init = function(self, pos)
        self.pos = pos
        self.state = false
		self.firstInputpinID = generateNewID()
		self.secondInputpinID = generateNewID()
		self.outputPinID = generateNewID()
		self.firstInputPinPos = { x = pos.x - (gateSize.width/5), y = pos.y + (gateSize.height/4) }
		self.secondInputpinPos = { x = pos.x - (gateSize.width/5), y = pos.y + (gateSize.height/4*3) }
		self.outputPinPos = { x = pos.x + gateSize.width + (gateSize.width/5), y = pos.y + (gateSize.height/2) }
    end,

	update = function(self)

	end,

	draw = function(self)
		drawGateTwoPins(self.pos)
		if mouseInRange(posi(self.firstInputPinPos.x, self.firstInputPinPos.y), 8)
			or mouseInRange(posi(self.secondInputpinPos.x, self.secondInputpinPos.y), 8)
			or mouseInRange(posi(self.outputPinPos.x, self.outputPinPos.y), 8) then
			lg.circle("fill", lm.getX(), lm.getY(), 8)
		end
        lg.print("AND",
			(self.pos.x + gateSize.width / 2) - (font:getWidth("AND")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end,

	checkPins = function(self)
		if isConnectingCable then
			if mouseInRange(posi(self.firstInputPinPos.x, self.firstInputPinPos.y), 8) then
				isConnectingCable = false
				firstConnectionPinID = self.firstInputpinID
				firstConnectionPinPos = self.firstInputPinPos
			elseif mouseInRange(posi(self.secondInputpinPos.x, self.secondInputpinPos.y), 8) then
				isConnectingCable = false
				firstConnectionPinID = self.secondInputpinID
				firstConnectionPinPos = self.secondInputPinPos
			elseif mouseInRange(posi(self.outputPinPos.x, self.outputPinPos.y), 8) then
				isConnectingCable = false
				firstConnectionPinID = self.outputPinID
				firstConnectionPinPos = self.outputPinPos
			end
		else
			if mouseInRange(posi(self.firstInputPinPos.x, self.firstInputPinPos.y), 8) then
				isConnectingCable = true
				firstConnectionPinID = self.firstInputpinID
				firstConnectionPinPos = self.firstInputPinPos
			elseif mouseInRange(posi(self.secondInputpinPos.x, self.secondInputpinPos.y), 8) then
				isConnectingCable = true
				firstConnectionPinID = self.secondInputpinID
				firstConnectionPinPos = self.secondInputPinPos
			elseif mouseInRange(posi(self.outputPinPos.x, self.outputPinPos.y), 8) then
				isConnectingCable = true
				firstConnectionPinID = self.outputPinID
				firstConnectionPinPos = self.outputPinPos
			end
		end
	end,
}

OR = Class{
    init = function(self, pos)
        self.pos = pos
        self.state = false
    end,

    update = function(self)
	end,

	draw = function(self)
		drawGateTwoPins(self.pos)
        lg.print("OR", 
			(self.pos.x + gateSize.width / 2) - (font:getWidth("OR")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end
}

NOT = Class{
    init = function(self, pos)
        self.pos = pos
        self.state = false
    end,

    update = function(self)
	end,

	draw = function(self)
		drawGateOnePin(self.pos)
        lg.print("NOT", 
			(self.pos.x + gateSize.width / 2) - (font:getWidth("NOT")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end
}

Input = Class{
    init = function(self, pos)
        self.pos = pos
        self.state = false
    end,

    update = function(self)
	end,

	draw = function(self)
		lg.setColor(0.2, 0.2, 0.2)
		lg.rectangle("fill", self.pos.x, self.pos.y, gateSize.width, gateSize.height)
		lg.setColor(1, 1, 1)
		lg.rectangle("line", self.pos.x, self.pos.y, gateSize.width, gateSize.height)
        lg.print("Input", 
			(self.pos.x + gateSize.width / 2) - (font:getWidth("Input")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end
}

Output = Class{
    init = function(self, pos)
        self.pos = pos
        self.state = false
    end,

    update = function(self)
	end,

	draw = function(self)
		lg.setColor(0.2, 0.2, 0.2)
		lg.rectangle("fill", self.pos.x, self.pos.y, gateSize.width, gateSize.height)
		lg.setColor(1, 1, 1)
		lg.rectangle("line", self.pos.x, self.pos.y, gateSize.width, gateSize.height)
        lg.print("Output", 
			(self.pos.x + gateSize.width / 2) - (font:getWidth("Output")/2), 
			(self.pos.y + gateSize.height / 2) - (fontHeight/2)
		)
	end
}

--=========================================================[ default functions ]==============================================================--

function love.load()
	menu = gui:group("MENU", bounds(0, 0, lg.getWidth(), lg.getHeight()))
	menu.display = true
	local start = gui:button("Start", bounds(10, 30, 100, 50), menu)
    local options = gui:button("Options", bounds(10, 90, 100, 50), menu)
	start.click = function(this)
		print("Start Pressed")
		menu.display = false
		menuState = menuEnum.board
	end

    --[[options.click = function(this)
		print("Options Pressed")
		menu.display = false
		menuState = menuEnum.options
	end

    optionsMenu = gui:group("Options", bounds(0, 0, lg.getWidth(), lg.getHeight()))
    menu.display = false
    local showFPS = gui:button("Show FPS", bounds(10, 30, 100, 50),optionsMenu)
    local FPSstate = false
    
    --local fullscreen = gui:button("Fullscreen", bounds(10, 30, 100, 50),optionsMenu)
    --local fullscreen = false

    showFPS.click = function(this)

        FPSstate = not FPSstate

        if (FPSstate) then
            print("FPS Shown")
            lg.setColor(1,1,1)
            lg.print("FPS: " .. love.timer.getFPS(), lg.getHeight - 10, 10 )
        elseif (not FPSstate) then
            print("FPS Hidden")
            lg.setColor(0,0,0)
            lg.print("FPS: " .. love.timer.getFPS(), lg.getHeight - 10, 10 )
        end
    end    


        
    ]]--

	contextMenu = gui:group("Menu", bounds(100, 100, 200, 200))
	contextMenu.display = false
	local ANDButton = gui:button("AND", bounds(padding, padding, 50, 50), contextMenu)
	ANDButton.click = function(this)
		table.insert(gates, AND(posi(lm.getX(), lm.getY())))
		showContextMenu = false
	end
	
	local ORButton = gui:button("OR", bounds(padding, padding, 50, 50), contextMenu)
	ORButton.click = function(this)
		table.insert(gates, OR(posi(lm.getX(), lm.getY())))
		showContextMenu = false
	end
	
	local NOTButton = gui:button("NOT", bounds(padding, padding, 50, 50), contextMenu)
	NOTButton.click = function(this)
		table.insert(gates, NOT(posi(lm.getX(), lm.getY())))
		showContextMenu = false
	end
	contextMenu:verticaltile()

	gui:updatepositions()

	table.insert(connections, { output = 3, input = 4 })
end

function love.update(dt)
	if menuState == menuEnum.board then
        for _,connection in ipairs(connections) do
			
            -- get state of gate of outputpin
			-- set state of gate of inputpin to that
        end
    end
	gui:update(dt)

    --[[
        if menuState == menuEnum.options then
			showFPS.click = function(this)

			FPSstate = not FPSstate

			if (FPSstate) then
				print("FPS Shown")
				lg.setColor(1,1,1)
				lg.print("FPS: " .. love.timer.getFPS(), lg.getHeight - 10, 10 )
			elseif (not FPSstate) then
				print("FPS Hidden")
				lg.setColor(0,0,0)
				lg.print("FPS: " .. love.timer.getFPS(), lg.getHeight - 10, 10 )
			end
		end
    ]]--
end

function love.draw()
	if menuState == menuEnum.board then
        for _,gate in ipairs(gates) do
            gate:draw()
        end

		if isConnectingCable then
			lg.line(firstConnectionPinPos.x, firstConnectionPinPos.y, lm.getX(), lm.getY())
		end

		contextMenu.display = showContextMenu
    end
	gui:draw()
end

function love.quit()

end

--==========================================================[ input functions ]===============================================================--

function love.mousepressed(x, y, button)
	if gui.hoverelement == nil and menuState == menuEnum.board then
		if button == 2 then
			showContextMenu = true
			contextMenu.absx = x
			contextMenu.absy = y
			for i,child in ipairs(contextMenu.children) do
				child.absx = x+padding + (55*(i-1))
				child.absy = y+fontHeight
			end
		elseif button == 1 and contextMenu.display == true then			
			showContextMenu = false
		end

		if button == 1 then
			for _,gate in ipairs(gates) do
				gate:checkPins()
			end
		end
	end
    
	gui:mousepress(x, y, button)
end

function love.mousereleased(x, y, button)
	gui:mouserelease(x, y, button)
end

function love.wheelmoved(dx, dy)
	gui:mousewheel(x, y)
end

function love.keypressed(key, unicode)
	gui:keypress(key)
end

function love.keyreleased(key, unicode)
end

function love.textinput(key)
	gui:textinput(key)
end